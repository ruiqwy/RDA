#'Dataset of growth of plant in chapter8
#'
#'A dataset containing weight and group 2 variables of 30 objects
#'
#'@format a dataframe with 30 rows and 2 variables
#'\describe{
#'  \item{weight}{weight}
#'  \item{group}{ctrl,trt1,trt2}
#'}
"plantgrowth"
