#'Dataset of agritural plant output and area in chapter11
#'
#'A dataset containing plant_area and output_value 2 variables of 29 objects
#'@format  a dataframe with 29 rows and 2 variables
#'\describe{
#'  \item{plant_area}{area for plant}
#'  \item{output_value}{output}
#'}
"plantarea_outputvalue"
