#'Dataset of students' math and stat score in chapter6
#'
#'A dataset containing math and stat 2 variables of 24 objects
#'
#'@format a dataframe with 24 rows and 2 variables
#'\describe{
#'  \item{math}{students' math score}
#'  \item{stat}{students' stat score}
#'}
"math_stat"
