#'Dataset of age and maxrate in chapter10
#'
#'A dataset containing Age and MaxRate of 15objects
#'@format a dataframe with 2 variables and 15 objects
#'\describe{
#'  \item{Age}{Age}
#'  \item{MaxRate}{maxrate}
#'}
"heart_maxrate"
